
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/admin.mjs
import crypto2 from "node:crypto";

// netlify/lib/state.mjs
import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";
var TZ = process.env.TZ_NAME || "Europe/Istanbul";
var today = () => (/* @__PURE__ */ new Date()).toLocaleDateString("sv-SE", { timeZone: TZ });
var store = () => getStore("vergi-defteri");
var defaults = () => ({
  settings: { guildName: "Lonca Ad\u0131", subtitle: "Vergi Defteri" },
  period: { start: today(), weeklyTax: "" },
  members: []
});
async function loadState() {
  const saved = await store().get("state", { type: "json" });
  return saved ? { ...defaults(), ...saved } : defaults();
}
async function saveState(state) {
  await store().setJSON("state", state);
}
function publicState(state) {
  return {
    settings: state.settings,
    period: state.period,
    members: state.members.map(({ discordId, prevLastPaid, ...m }) => m)
  };
}
var clean = (v, max = 60) => String(v ?? "").replace(/\s+/g, " ").trim().slice(0, max);
var newId = () => crypto.randomUUID();
function markPaid(m) {
  if (m.status !== "paid") {
    m.prevLastPaid = m.lastPaid || "";
    m.lastPaid = today();
  }
  m.status = "paid";
}
function markUnpaid(m) {
  if (m.status === "paid") m.lastPaid = m.prevLastPaid || "";
  m.status = "unpaid";
}

// netlify/functions/admin.mjs
var SECRET = () => process.env.SESSION_SECRET || process.env.ADMIN_PASSWORD || "";
var sign = (payload) => crypto2.createHmac("sha256", SECRET()).update(payload).digest("base64url");
function makeToken() {
  const payload = Buffer.from(
    JSON.stringify({ exp: Date.now() + 12 * 60 * 60 * 1e3 })
  ).toString("base64url");
  return payload + "." + sign(payload);
}
function checkToken(token) {
  if (!token || !SECRET()) return false;
  const [payload, sig] = token.split(".");
  if (!payload || !sig) return false;
  const a = Buffer.from(sig);
  const b = Buffer.from(sign(payload));
  if (a.length !== b.length || !crypto2.timingSafeEqual(a, b)) return false;
  try {
    return JSON.parse(Buffer.from(payload, "base64url").toString()).exp > Date.now();
  } catch {
    return false;
  }
}
function samePassword(input) {
  const pw = process.env.ADMIN_PASSWORD;
  if (!pw) return false;
  const h = (s) => crypto2.createHash("sha256").update(String(s)).digest();
  return crypto2.timingSafeEqual(h(input), h(pw));
}
var json = (data, status = 200) => Response.json(data, { status, headers: { "cache-control": "no-store" } });
var admin_default = async (req) => {
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  let body;
  try {
    body = await req.json();
  } catch {
    return json({ error: "Ge\xE7ersiz istek" }, 400);
  }
  if (body.action === "login") {
    if (!samePassword(body.password ?? "")) {
      await new Promise((r) => setTimeout(r, 800));
      return json({ error: "\u015Eifre yanl\u0131\u015F" }, 401);
    }
    return json({ token: makeToken() });
  }
  const bearer = (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
  if (!checkToken(bearer)) return json({ error: "Yetkisiz" }, 401);
  const state = await loadState();
  const find = (id) => state.members.find((m) => m.id === id);
  switch (body.action) {
    case "setStatus": {
      const m = find(body.id);
      if (!m) return json({ error: "\xDCye bulunamad\u0131" }, 404);
      if (body.status === "paid") markPaid(m);
      else if (body.status === "unpaid") markUnpaid(m);
      else return json({ error: "Ge\xE7ersiz durum" }, 400);
      break;
    }
    case "saveMember": {
      const fields = {
        nick: clean(body.nick, 30),
        class: clean(body.class, 30),
        owner: clean(body.owner, 40),
        discord: clean(body.discord, 40),
        note: clean(body.note, 200)
      };
      if (!fields.nick) return json({ error: "Karakter ad\u0131 gerekli" }, 400);
      const dup = state.members.find(
        (x) => x.id !== body.id && x.nick.toLowerCase() === fields.nick.toLowerCase()
      );
      if (dup) return json({ error: "Bu karakter ad\u0131 zaten listede" }, 409);
      if (body.id) {
        const m = find(body.id);
        if (!m) return json({ error: "\xDCye bulunamad\u0131" }, 404);
        Object.assign(m, fields);
      } else {
        state.members.push({ id: newId(), ...fields, status: "unpaid", lastPaid: "" });
      }
      break;
    }
    case "deleteMember":
      state.members = state.members.filter((m) => m.id !== body.id);
      break;
    case "saveSettings":
      state.settings = {
        guildName: clean(body.guildName, 40) || state.settings.guildName,
        subtitle: clean(body.subtitle, 60) || state.settings.subtitle
      };
      state.period.weeklyTax = clean(body.weeklyTax, 40);
      break;
    case "newPeriod":
      state.period.start = today();
      for (const m of state.members) m.status = "unpaid";
      break;
    default:
      return json({ error: "Bilinmeyen i\u015Flem" }, 400);
  }
  await saveState(state);
  return json({ state: publicState(state) });
};
var config = { path: "/api/admin" };
export {
  config,
  admin_default as default
};
