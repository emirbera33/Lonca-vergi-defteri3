
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/discord.mjs
import crypto2 from "node:crypto";

// netlify/lib/state.mjs
import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";
var TZ = process.env.TZ_NAME || "Europe/Istanbul";
var today = () => (/* @__PURE__ */ new Date()).toLocaleDateString("sv-SE", { timeZone: TZ });
var store = () => getStore("vergi-defteri");
var defaults = () => ({
  settings: { guildName: "Lonca Ad\u0131", subtitle: "Vergi Defteri" },
  period: { start: today(), weeklyTax: "" },
  members: []
});
async function loadState() {
  const saved = await store().get("state", { type: "json" });
  return saved ? { ...defaults(), ...saved } : defaults();
}
async function saveState(state) {
  await store().setJSON("state", state);
}
var clean = (v, max = 60) => String(v ?? "").replace(/\s+/g, " ").trim().slice(0, max);
var newId = () => crypto.randomUUID();
function markPaid(m) {
  if (m.status !== "paid") {
    m.prevLastPaid = m.lastPaid || "";
    m.lastPaid = today();
  }
  m.status = "paid";
}

// netlify/functions/discord.mjs
var SPKI_PREFIX = Buffer.from("302a300506032b6570032100", "hex");
function verify(rawBody, signature, timestamp) {
  try {
    if (!signature || !timestamp || !process.env.DISCORD_PUBLIC_KEY) return false;
    const key = crypto2.createPublicKey({
      key: Buffer.concat([SPKI_PREFIX, Buffer.from(process.env.DISCORD_PUBLIC_KEY, "hex")]),
      format: "der",
      type: "spki"
    });
    return crypto2.verify(
      null,
      Buffer.from(timestamp + rawBody),
      key,
      Buffer.from(signature, "hex")
    );
  } catch {
    return false;
  }
}
var GOLD = 14723387;
var reply = (content) => Response.json({
  type: 4,
  data: { content, flags: 64, allowed_mentions: { parse: [] } }
});
var isAdmin = (i) => {
  try {
    const p = BigInt(i.member?.permissions ?? "0");
    return (p & 0x8n) !== 0n || (p & 0x20n) !== 0n;
  } catch {
    return false;
  }
};
var userOf = (i) => i.member?.user ?? i.user;
function registerModal() {
  const row = (custom_id, label, required, max) => ({
    type: 1,
    components: [{ type: 4, custom_id, label, style: 1, required, max_length: max }]
  });
  return Response.json({
    type: 9,
    data: {
      custom_id: "register_modal",
      title: "Lonca Kayd\u0131",
      components: [
        row("nick", "Karakter ad\u0131", true, 30),
        row("class", "S\u0131n\u0131f (iste\u011Fe ba\u011Fl\u0131)", false, 30),
        row("owner", "Sahip (bo\u015Fsa Discord ad\u0131n yaz\u0131l\u0131r)", false, 40)
      ]
    }
  });
}
async function handleRegister(i) {
  const user = userOf(i);
  const vals = {};
  for (const row of i.data.components ?? [])
    for (const c of row.components ?? []) vals[c.custom_id] = c.value;
  const nick = clean(vals.nick, 30);
  if (nick.length < 2) return reply("Karakter ad\u0131 en az 2 karakter olmal\u0131.");
  const cls = clean(vals.class, 30);
  const owner = clean(vals.owner, 40) || user.global_name || user.username;
  const state = await loadState();
  const taken = state.members.find(
    (m) => m.nick.toLowerCase() === nick.toLowerCase() && m.discordId !== user.id
  );
  if (taken)
    return reply(`**${nick}** ad\u0131 listede zaten kay\u0131tl\u0131. Hata oldu\u011Funu d\xFC\u015F\xFCn\xFCyorsan y\xF6neticiye yaz.`);
  const existing = state.members.find((m) => m.discordId === user.id);
  if (existing) {
    Object.assign(existing, { nick, class: cls || existing.class, owner, discord: user.username });
  } else {
    state.members.push({
      id: newId(),
      nick,
      class: cls,
      owner,
      discord: user.username,
      discordId: user.id,
      status: "unpaid",
      lastPaid: "",
      note: ""
    });
  }
  await saveState(state);
  return reply(
    existing ? `\u2705 Kayd\u0131n g\xFCncellendi: **${nick}**` : `\u2705 Kayd\u0131n al\u0131nd\u0131, listeye eklendin: **${nick}**`
  );
}
async function handlePaid(i) {
  const user = userOf(i);
  const state = await loadState();
  const m = state.members.find((x) => x.discordId === user.id);
  if (!m) return reply("\xD6nce kay\u0131t odas\u0131ndan kay\u0131t olmal\u0131s\u0131n, sonra tekrar dene.");
  if (m.status === "paid") return reply("Bu d\xF6nem i\xE7in zaten **\xD6dendi** g\xF6r\xFCn\xFCyorsun \u{1F44D}");
  if (m.status === "pending") return reply("\xD6demen zaten y\xF6netici onay\u0131 bekliyor.");
  if (process.env.REQUIRE_APPROVAL === "true") {
    m.status = "pending";
    await saveState(state);
    return reply("\u23F3 \xD6deme bildirimin al\u0131nd\u0131. Y\xF6netici onaylay\u0131nca listede **\xD6dendi** olacak.");
  }
  markPaid(m);
  await saveState(state);
  return reply("\u2705 \xD6dendi olarak i\u015Faretlendi, te\u015Fekk\xFCrler!");
}
function panel(title, description, label, custom_id, style) {
  const site = process.env.SITE_URL ? `

Liste: ${process.env.SITE_URL}` : "";
  return Response.json({
    type: 4,
    data: {
      embeds: [{ title, description: description + site, color: GOLD }],
      components: [{ type: 1, components: [{ type: 2, style, label, custom_id }] }]
    }
  });
}
var discord_default = async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const raw = await req.text();
  if (!verify(raw, req.headers.get("x-signature-ed25519"), req.headers.get("x-signature-timestamp")))
    return new Response("invalid request signature", { status: 401 });
  const i = JSON.parse(raw);
  if (i.type === 1) return Response.json({ type: 1 });
  if (i.type === 2) {
    if (!isAdmin(i)) return reply("Bu komutu sadece y\xF6neticiler kullanabilir.");
    if (i.data.name === "kayit-paneli")
      return panel(
        "Lonca Kayd\u0131",
        "A\u015Fa\u011F\u0131daki butona bas\u0131p karakter ad\u0131n\u0131 gir. Kayd\u0131n otomatik olarak vergi listesine eklenir.",
        "Kay\u0131t Ol",
        "register",
        1
      );
    if (i.data.name === "odeme-paneli")
      return panel(
        "Vergi \xD6demesi",
        "Vergini \xF6dedikten sonra a\u015Fa\u011F\u0131daki butona bas. Listedeki durumun g\xFCncellenir.",
        "\xD6dendi",
        "paid",
        3
      );
  }
  if (i.type === 3) {
    if (i.data.custom_id === "register") return registerModal();
    if (i.data.custom_id === "paid") return handlePaid(i);
  }
  if (i.type === 5 && i.data.custom_id === "register_modal") return handleRegister(i);
  return reply("Bilinmeyen i\u015Flem.");
};
var config = { path: "/api/discord" };
export {
  config,
  discord_default as default
};
