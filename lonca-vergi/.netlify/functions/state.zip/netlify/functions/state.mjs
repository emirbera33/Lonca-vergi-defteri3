
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/state.mjs
import { getStore } from "@netlify/blobs";
var TZ = process.env.TZ_NAME || "Europe/Istanbul";
var today = () => (/* @__PURE__ */ new Date()).toLocaleDateString("sv-SE", { timeZone: TZ });
var store = () => getStore("vergi-defteri");
var defaults = () => ({
  settings: { guildName: "Lonca Ad\u0131", subtitle: "Vergi Defteri" },
  period: { start: today(), weeklyTax: "" },
  members: []
});
async function loadState() {
  const saved = await store().get("state", { type: "json" });
  return saved ? { ...defaults(), ...saved } : defaults();
}
function publicState(state) {
  return {
    settings: state.settings,
    period: state.period,
    members: state.members.map(({ discordId, prevLastPaid, ...m }) => m)
  };
}

// netlify/functions/state.mjs
var state_default = async () => {
  const state = await loadState();
  return Response.json(publicState(state), {
    headers: { "cache-control": "no-store" }
  });
};
var config = { path: "/api/state" };
export {
  config,
  state_default as default
};
